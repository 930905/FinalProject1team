console.log("장바구니 조회 실행!");
var basketService = (function() {

	function getList(param, callback, error) {
		var p_buyer = param.p_buyer;
		
		$.getJSON("/basket/select/" + p_buyer + ".json", function(data) {
			if (callback) {
				// Page437 코딩할 때, 아래 1줄 소스는 주석 처리를 해줍니다.
				callback(data.list);
			}
		}).fail(function(xhr, status, err) {
			if (error) {
				error();
			}
		});
	}
	
	function remove(param, callback, error) {
		var p_buyer = param.p_buyer;
		var pnum = param.pnum;
		$.ajax({
			// remove() 메서드는 DELETE 방식으로 데이터를 전달하므로,
			// $.ajax()를 이용해서 구체적으로 type 속성으로 'delete'를 지정합니다.
			// 이제, get.jsp 에서 실제 데이터베이스 댓글 번호를 이용해서 정상적으로
			// 댓글이 삭제되는지를 소스 코딩 확인해 봅니다.
			type : 'delete',
			url : '/basket/remove/' + pnum + "/" + p_buyer,
			contentType : "application/json",
			success : function(deleteResult, status, xhr) {
				if (callback) {
					callback(deleteResult);
				}
			},
			error : function(xhr, status, er) {
				if (error) {
					error(er);
				}
			}
		});
	}

	return {
		getList : getList,
		remove : remove
	};
})();