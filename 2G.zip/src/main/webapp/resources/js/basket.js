
console.log("장바구니 조회 실행!");
var basketService = (function(){
	
function getList(param, callback, error) {
	var p_buyer = param.p_buyer;
	$.getJSON("/basket/select/" + p_buyer + ".json",
			function(data) {
				if (callback) {
					// Page437 코딩할 때, 아래 1줄 소스는 주석 처리를 해줍니다.						
					callback(data.list);
				}
			}).fail(function(xhr, status, err) {
				if (error) {
					error();
				}
			});
	}
	return {
		getList : getList
	};
})();