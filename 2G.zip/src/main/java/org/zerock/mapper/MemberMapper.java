package org.zerock.mapper;

import org.apache.ibatis.annotations.Param;
import org.zerock.domain.MemberVO;

public interface MemberMapper {

	// 로그인
	public MemberVO login(@Param("id") String id, @Param("password") String password);
	
	// 회원가입
	public void register(MemberVO vo);
	
	// 아이디 찾기
	public MemberVO findId(@Param("name") String name, @Param("email") String email);
	
	// 비밀번호 찾기
	public MemberVO findPassword(@Param("id") String id, @Param("email") String name);

	// 회원탈퇴
	public boolean remove(String id);

	// 회원정보수정
	public int update(MemberVO vo);
	
	// 회원조회
	public MemberVO read(String id);
	
	
	
}
