package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.ProductVO;

public interface ProductMapper {

	public List<ProductVO> select();
	
}
