package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.BasketVO;

public interface BasketMapper {

	public List<BasketVO> select(String p_buyer);
	
	public int insert(BasketVO vo);
	
	public boolean remove();
	
}
