package org.zerock.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.zerock.domain.BasketVO;
import org.zerock.domain.Basket_orderVO;

public interface BasketMapper {

	public List<BasketVO> select(String p_buyer);
	
	public int order_insert(Basket_orderVO vo);
	
	public int insert(BasketVO vo);
	
	public int remove(@Param("pnum") int pnum, @Param("id") String id);
	
	public int remove_basket(String id);
	
}
