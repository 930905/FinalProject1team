package org.zerock.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.zerock.domain.MemberVO;
import org.zerock.service.MemberService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@CrossOrigin
@Controller
@Log4j
@AllArgsConstructor
@RequestMapping("/member/*")
public class MemberController {
	private MemberService service;
	
	@RequestMapping("/")
	public String index() {
		return "/index.jsp";
	}
	
	@PostMapping("/login_check")
	public void login_check(@RequestParam("id") String id, @RequestParam("password") String password,  Model model, HttpServletRequest request) {
		log.info("조회 수행합니다");
		MemberVO vo = service.login(id, password);
		model.addAttribute("login",vo);
		if (vo != null) {
			HttpSession session = request.getSession();
			session.setAttribute("login", vo);
 		}
	}
	@PostMapping("/logout")
	public String logout(HttpServletRequest request) {
	    // 새로 생성하지 않는 조건(false)로 세션을 조회한다
		log.info("회원탈퇴");
	    HttpSession session = request.getSession(false);
	    if (session != null) {
	        session.invalidate(); // 세션 정보를 삭제한다
	    }
	    return "redirect:/";
	}
	
	@PostMapping("/register_check")
	public void sign_in(MemberVO vo, Model model) {
		MemberVO result = service.read(vo.getId());
		log.info(result);
		model.addAttribute("register",vo);
		if (result == null) {
			model.addAttribute("result","success");
		} else {
			model.addAttribute("result","false");
		}
	}
	
	@PostMapping("/register")
	public String register(MemberVO vo) {
		log.info("회원가입 실행합니다!");
		service.register(vo);
		return "redirect:/";
	}
	
	@PostMapping("/sign_out")
	public String remove(@RequestParam("id") String id, HttpServletRequest request) {
		// 새로 생성하지 않는 조건(false)로 세션을 조회한다
	    HttpSession session = request.getSession(false);
	    if (session != null) {
	        session.invalidate(); // 세션 정보를 삭제한다
	        log.info("삭제하는 아이디 : " + id);
	        service.remove(id);
	    }
	    return "redirect:/";
	}
	
	@PostMapping("/findId")
	public void findId(@RequestParam("name") String name, @RequestParam("email") String email, Model model) {
		log.info("찾는 아이디 이름 : " + name);
		log.info("찾는 아이디 이메일 : " + email);
		MemberVO result = service.findId(name, email);
		log.info(result);
		model.addAttribute("result",result);
	}
	
	@PostMapping("/findPassword")
	public void findPassword(@RequestParam("id") String id, @RequestParam("email") String email, Model model) {
		log.info("찾는 비밀번호의 아이디 : " + id);
		log.info("찾는 비밀번호의 이메일 : " + email);
		MemberVO result = service.findPassword(id, email);
		model.addAttribute("result",result);
	}
	
}
