package org.zerock.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.zerock.domain.BasketVO;
import org.zerock.service.BasketService;
import org.zerock.service.ProductService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@AllArgsConstructor
@Log4j
@RequestMapping("/product/*")
public class ProductController {
	
	private ProductService p_service;
	private BasketService b_service;

	@GetMapping("/mobile")
	public void p_select(Model model) {
		log.info("상품목록 조회합니다!");
		model.addAttribute("list", p_service.select());
	}
	
	@PostMapping("/basket")
	public String basket(BasketVO vo) {
		log.info("장바구니에 추가합니다!");
		b_service.insert(vo);
		return "redirect:/product/mobile";
	}
	
}
