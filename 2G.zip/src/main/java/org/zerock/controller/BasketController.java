package org.zerock.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.BasketDTO;
import org.zerock.domain.Basket_orderVO;
import org.zerock.service.BasketService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RestController
@Log4j
@AllArgsConstructor
@RequestMapping("/basket/*")
public class BasketController {
	
	private BasketService service;
	
	@GetMapping(value = "/select/{p_buyer}")
	public ResponseEntity<BasketDTO> select(@PathVariable("p_buyer") String p_buyer){
		log.info("장바구니 조회 실행");
		return new ResponseEntity<BasketDTO>(service.select_basket(p_buyer),HttpStatus.OK);
	}
	
	@DeleteMapping(value = "/remove/{pnum}/{id}", consumes = "application/json", produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> remove(@PathVariable("pnum") int pnum, @PathVariable("id") String id){
		log.info("삭제 처리 id : " + id + "pnum : " + pnum);
		
		return service.remove(pnum, id) == 1
				? new ResponseEntity<String>("success", HttpStatus.OK)
				: new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PostMapping(value = "/payment", consumes = "application/json", produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> payment(@RequestBody Basket_orderVO vo){
		log.info("장바구니 데이터 결제 실행!");
		int insertCount = service.basket_insert(vo);
		log.info(insertCount);
		log.info(vo.getP_buyer());
		if (insertCount > 0) {
			service.remove_basket(vo.getP_buyer());
		}
		return insertCount > 0
				? new ResponseEntity<String>("success",HttpStatus.OK)
				: new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
			

}
