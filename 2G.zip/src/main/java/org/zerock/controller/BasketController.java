package org.zerock.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.BasketDTO;
import org.zerock.service.BasketService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RestController
@Log4j
@AllArgsConstructor
@RequestMapping("/basket/*")
public class BasketController {
	
	private BasketService service;
	
	@GetMapping(value = "/select/{p_buyer}")
	public ResponseEntity<BasketDTO> select(@PathVariable("p_buyer") String p_buyer){
		log.info("장바구니 조회 실행");
		return new ResponseEntity<BasketDTO>(service.select(p_buyer),HttpStatus.OK);
	}

}
