package org.zerock.service;

import java.util.List;

import org.zerock.domain.ProductVO;

public interface ProductService {

	public List<ProductVO> select_mobile();
	
	public List<ProductVO> select_goods();
	
	public List<ProductVO> select_cd();
	
	public List<ProductVO> select_console();
	
}
