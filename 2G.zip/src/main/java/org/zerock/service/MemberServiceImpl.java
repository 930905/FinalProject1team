package org.zerock.service;

import org.springframework.stereotype.Service;
import org.zerock.domain.MemberVO;
import org.zerock.mapper.MemberMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class MemberServiceImpl implements MemberService{

	private MemberMapper mapper;

	@Override
	public MemberVO login(String id, String password) {
		log.info("로그인 아이디 비번 확인!");
		return mapper.login(id, password);
	}

	@Override
	public void register(MemberVO vo) {
		log.info("회원가입 등록 실행!");
		mapper.register(vo);
	}

	@Override
	public MemberVO read(String id) {
		log.info("회원 조회 실행!");
		return mapper.read(id);
	}
	
	@Override
	public int update(MemberVO vo) {
		log.info("회원정보 업데이트 실행!");
		return mapper.update(vo);
	}

	@Override
	public boolean remove(String id) {
		log.info("회원탈퇴 실행!");
		return mapper.remove(id);
	}

	@Override
	public MemberVO findId(String name, String email) {
		log.info("아이디 찾기 실행!");
		return mapper.findId(name, email);
	}

	@Override
	public MemberVO findPassword(String id, String email) {
		log.info("비밀번호 찾기 실행!");
		return mapper.findPassword(id, email);
	}


}
