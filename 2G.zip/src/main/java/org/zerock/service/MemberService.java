package org.zerock.service;

import org.apache.ibatis.annotations.Param;
import org.zerock.domain.MemberVO;

public interface MemberService {
	
	public MemberVO login(@Param("id") String id, @Param("password") String password);
	
	public void register(MemberVO vo);
	
	public MemberVO read(String id);
	
	public boolean remove(String id);
	
	public MemberVO findId(@Param("name") String name, @Param("email") String email);
	
	public MemberVO findPassword(@Param("id") String id, @Param("email") String email);
}
