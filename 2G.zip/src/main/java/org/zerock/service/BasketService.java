package org.zerock.service;

import org.zerock.domain.BasketDTO;
import org.zerock.domain.BasketVO;

public interface BasketService {
	
	public int insert(BasketVO vo);
	
	public BasketDTO select(String p_buyer);
	
}
