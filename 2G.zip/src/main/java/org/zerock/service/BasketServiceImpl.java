package org.zerock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zerock.domain.BasketDTO;
import org.zerock.domain.BasketVO;
import org.zerock.domain.Basket_orderVO;
import org.zerock.mapper.BasketMapper;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class BasketServiceImpl implements BasketService{

	@Autowired
	private BasketMapper mapper;
	
	@Override
	public int insert(BasketVO vo) {
		log.info("장바구니 추가 실행!");
		return mapper.insert(vo);
	}


	@Override
	public int remove(int pnum, String id) {
		log.info("장바구니 삭제 실행");
		return mapper.remove(pnum, id);
	}

	@Override
	public BasketDTO select_basket(String p_buyer) {
		log.info("장바구니 조회 실행");
		return new BasketDTO(mapper.select(p_buyer));
	}

	@Override
	public List<BasketVO> order_basket(String p_buyer) {
		log.info("장바구니 주문 실행");
		return mapper.select(p_buyer);
	}


	@Override
	public int basket_insert(Basket_orderVO vo) {
		log.info("장바구니 결제 실행!");
		return mapper.order_insert(vo);
	}


	@Override
	public int remove_basket(String id) {
		return mapper.remove_basket(id);
	}
	
}
