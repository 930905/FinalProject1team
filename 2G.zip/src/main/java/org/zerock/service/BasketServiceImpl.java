package org.zerock.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zerock.domain.BasketDTO;
import org.zerock.domain.BasketVO;
import org.zerock.mapper.BasketMapper;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class BasketServiceImpl implements BasketService{

	@Autowired
	private BasketMapper mapper;
	
	@Override
	public int insert(BasketVO vo) {
		log.info("장바구니 추가 실행!");
		return mapper.insert(vo);
	}

	@Override
	public BasketDTO select(String p_buyer) {
		return new BasketDTO(mapper.select(p_buyer));
	}
	
}
