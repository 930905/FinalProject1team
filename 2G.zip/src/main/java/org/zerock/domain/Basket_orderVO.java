package org.zerock.domain;

import lombok.Data;

@Data
public class Basket_orderVO {

	private String pno;
	private int pnum;
	private String pname;
	private int pamount;
	private int p_price;
	private String p_buyer;
	
}
