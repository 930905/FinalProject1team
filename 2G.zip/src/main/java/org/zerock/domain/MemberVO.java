package org.zerock.domain;

import java.sql.Date;

import lombok.Data;

@Data
public class MemberVO {

	private String id;
	private String password;
	private String name;
	private String email;
	private Date birth;
	private String address; // 합쳐진 주소
	private String roadAddrPart1;
	private String addrDetail;
	private Character gender;
	private String p_num;
	
	public void address() {
		this.address = this.roadAddrPart1 + "," + this.addrDetail;
	}
}