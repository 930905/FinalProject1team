package org.zerock.domain;

import java.sql.Date;

import lombok.Data;

@Data
public class BasketVO {

	private int pnum;
	private String pname;
	private String p_buyer;
	private int pamount;
	private int p_price;
	private Date pdate;
	
}
