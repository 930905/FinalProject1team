package com.springboot.androidapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.androidapp.model.Order;

public interface OrderRepository extends JpaRepository<Order, String>{
	
	List<Order> findAllByPbuyer(String pbuyer);
	
	String deleteByPno(String pno);
	
	Order findByPno(String pno);
}
