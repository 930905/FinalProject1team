package com.springboot.androidapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAndroidApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAndroidApp1Application.class, args);
		System.out.println("스프링 부트 테스트!");
	}

}
