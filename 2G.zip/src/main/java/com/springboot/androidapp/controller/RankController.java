package com.springboot.androidapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.androidapp.model.RankDTO;
import com.springboot.androidapp.service.RankService;

@CrossOrigin
@RestController
public class RankController {
	
	@Autowired
	RankService service;
	
	@GetMapping("/rank")
	public ResponseEntity<RankDTO> select() throws Exception{
		return new ResponseEntity<RankDTO>(service.select(),HttpStatus.OK);
	}
	
	@PostMapping("/vote/{eno}")
	public ResponseEntity<?> insert(@PathVariable("eno") int eno) throws Exception{
		System.out.println(eno);
		return new ResponseEntity<>(service.insert(eno),HttpStatus.OK);
	}

}
