package com.springboot.androidapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.androidapp.model.OrderDTO;
import com.springboot.androidapp.service.OrderService;

@CrossOrigin
@RestController
public class OrderController {
	
	@Autowired
	OrderService service;
	
	@GetMapping("/order/{pbuyer}")
	public ResponseEntity<OrderDTO> select(@PathVariable("pbuyer") String pbuyer) throws Exception{
		System.out.println(pbuyer);
		return new ResponseEntity<OrderDTO>(service.select(pbuyer),HttpStatus.OK);
	}
	
	@DeleteMapping("/order_delete/{pno}")
	public ResponseEntity<String> deleteById(@PathVariable("pno") String pno) throws Exception{
		System.out.println(pno);
		return new ResponseEntity<String>(service.delete(pno), HttpStatus.OK); // 삭제하기 200
	}
	
	@PutMapping("/order_update/{pno}")
	public ResponseEntity<String> updateByPno(@PathVariable("pno") String pno) throws Exception{
		System.out.println(pno);
		return new ResponseEntity<String>(service.update(pno),HttpStatus.OK);
	}

}
