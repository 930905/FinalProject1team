package com.springboot.androidapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.androidapp.model.EventDTO;
import com.springboot.androidapp.service.EventService;

@CrossOrigin
@RestController
public class EventController {
	
	@Autowired
	EventService service;
	
	@GetMapping("/event/{category}")
	public ResponseEntity<EventDTO> select(@PathVariable("category") String category) throws Exception{
		System.out.println(category);
		return new ResponseEntity<EventDTO>(service.select(category),HttpStatus.OK);
	}

}
