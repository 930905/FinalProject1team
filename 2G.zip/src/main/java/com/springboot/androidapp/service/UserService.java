package com.springboot.androidapp.service;

import com.springboot.androidapp.model.User;

public interface UserService {
	
	User select(User vo);
}
