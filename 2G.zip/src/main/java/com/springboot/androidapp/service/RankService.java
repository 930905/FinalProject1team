package com.springboot.androidapp.service;

import com.springboot.androidapp.model.Rank;
import com.springboot.androidapp.model.RankDTO;

public interface RankService {

	public RankDTO select() throws Exception;
	
	public Rank insert(int eno) throws Exception;
}
