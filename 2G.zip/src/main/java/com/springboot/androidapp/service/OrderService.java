package com.springboot.androidapp.service;

import com.springboot.androidapp.model.OrderDTO;

public interface OrderService {
	
	public OrderDTO select(String pbuyer) throws Exception;
	
	public String delete(String pno) throws Exception;
	
	public String update(String pno) throws Exception;

}
