package com.springboot.androidapp.service;

import com.springboot.androidapp.model.EventDTO;

public interface EventService {
	
	public EventDTO select(String cateory) throws Exception;

}
