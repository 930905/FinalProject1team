package com.springboot.androidapp.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.androidapp.model.Order;
import com.springboot.androidapp.model.OrderDTO;
import com.springboot.androidapp.repository.OrderRepository;
import com.springboot.androidapp.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	OrderRepository repo;

	@Override
	public OrderDTO select(String pbuyer) throws Exception {
		return new OrderDTO(repo.findAllByPbuyer(pbuyer));
	}
	
	@Transactional
	@Override
	public String delete(String pno) throws Exception {
		repo.deleteByPno(pno);
		return "OK";
	}

	@Override
	public String update(String pno) throws Exception {
		Order order = repo.findByPno(pno);
		 if (order != null) {
			 order.setOrder_status('Y');
		        repo.save(order);
		    } else {
		        throw new Exception("주문을 찾을 수 없습니다. pno: " + pno);
		    }
		return "OK";
	}

}
