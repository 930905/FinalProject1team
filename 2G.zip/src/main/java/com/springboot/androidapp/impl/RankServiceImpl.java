package com.springboot.androidapp.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.androidapp.model.Rank;
import com.springboot.androidapp.model.RankDTO;
import com.springboot.androidapp.repository.RankRepository;
import com.springboot.androidapp.service.RankService;

@Service
public class RankServiceImpl implements RankService{

	@Autowired
	RankRepository repo;
	
	@Override
	public RankDTO select() throws Exception {
		return new RankDTO(repo.findAllByOrderByVoteDesc());
	}

	@Override
	public Rank insert(int eno) throws Exception {
		Rank rank = repo.findByEno(eno);
		rank.setVote(rank.getVote() + 1);
		return repo.save(rank);
	}

}
