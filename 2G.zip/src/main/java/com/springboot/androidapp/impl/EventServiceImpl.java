package com.springboot.androidapp.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.androidapp.model.EventDTO;
import com.springboot.androidapp.repository.EventRepository;
import com.springboot.androidapp.service.EventService;

@Service
public class EventServiceImpl implements EventService{
	
	@Autowired
	EventRepository repo;

	@Override
	public EventDTO select(String category) throws Exception {
		return new EventDTO(repo.findAllByCategory(category));
	}
	
	

}
