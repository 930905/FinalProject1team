package com.springboot.androidapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "product")
@Data
public class Event {

	@Id
	@Column(name = "pno")
	private int pno;
	
	@Column(name = "pname")
	private String pname;
	
	@Column(name = "pprice")
	private int pprice;
	
	@Column(name = "category")
	private String category;
	
	
	
}
