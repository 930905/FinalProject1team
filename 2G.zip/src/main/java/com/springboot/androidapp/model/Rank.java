package com.springboot.androidapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "new_event")
@Data
public class Rank {

	@Id
	@Column(name = "ENO")
	int eno;
	
	@Column(name = "PNAME")
	String pname;
	
	@Column(name = "VOTE")
	int vote;
	
}
