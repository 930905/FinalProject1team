package com.springboot.androidapp.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "basket_order")
@Data
public class Order {

	@Id
	@Column(name = "PNO")
	private String pno;
	
	@Column(name = "PNUM")
	private int pnum;
	
	@Column(name = "PNAME")
	private String pname;
	
	@Column(name = "PAMOUNT")
	private int pamount;
	
	@Column(name = "P_PRICE")
	private int p_price;
	
	@Column(name = "PBUYER")
	private String pbuyer;
	
	@Column(name = "PDATE")
	private Date pdate;
	
	@Column(name = "ORDER_STATUS")
	private Character order_status;

}
