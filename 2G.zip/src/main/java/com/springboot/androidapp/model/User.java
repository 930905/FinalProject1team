package com.springboot.androidapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "member")
@Getter
@Setter
@ToString
public class User {
	
	@Id
	@Column(name = "id")
	private String userId;
	@Column(name = "password")
	private String userPassword;
//	@Column(name = "email")
//	private String userEmail;
//	@Column(name = "birth")
//	private String userBirth;
//	@Column(name = "address")
//	private String userAddress;
//	@Column(name = "gender")
//	private String userGender;
//	@Column(name = "p_num")
//	private String userP_num;
//	@Column(name = "name")
//	private String userName;
	
}
