
/* Drop Tables */

DROP TABLE TBL_ATTACH CASCADE CONSTRAINTS;
DROP TABLE TBL_REPLY CASCADE CONSTRAINTS;
DROP TABLE TBL_Board CASCADE CONSTRAINTS;




/* Create Tables */

CREATE TABLE TBL_ATTACH
(
	UUID varchar2(100) NOT NULL,
	BNO number(10,0) NOT NULL,
	UploadPath varchar2(200),
	FileName varchar2(100),
	FileType char(1),
	PRIMARY KEY (UUID)
);


CREATE TABLE TBL_Board
(
	BNO number(10,0) NOT NULL,
	TITLE varchar2(200) NOT NULL,
	CONTENT varchar2(2000) NOT NULL,
	WRITER varchar2(50) NOT NULL,
	REGDATE date,
	UPDATEDATE date,
	HIT number,
	PRIMARY KEY (BNO)
);


CREATE TABLE TBL_REPLY
(
	Rno number(10,0) NOT NULL,
	BNO number(10,0) NOT NULL,
	Reply varchar2(1000) NOT NULL,
	Replyer varchar2(50) NOT NULL,
	ReplyData date DEFAULT sysdate,
	upadateDate date DEFAULT sysdate,
	PRIMARY KEY (Rno)
);



/* Create Foreign Keys */

ALTER TABLE TBL_ATTACH
	ADD FOREIGN KEY (BNO)
	REFERENCES TBL_Board (BNO)
;


ALTER TABLE TBL_REPLY
	ADD FOREIGN KEY (BNO)
	REFERENCES TBL_Board (BNO)
;



