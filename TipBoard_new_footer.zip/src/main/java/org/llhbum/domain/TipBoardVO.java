package org.llhbum.domain;

import java.util.Date;
import java.util.List;

import lombok.Data;

// 1. DB의 컬럼과 맞게 작성해준다.
// Lombok을 사용해서 getter,setter를 처리해준다.

@Data
public class TipBoardVO {
	
	private Long bno;
	private String title;
	private String content;
	private String writer;
	private Date regdate;
	private Date updateDate;
	private Long hit;
	
	private int replycnt;
	
	private List<TipBoardAttachVO> attachList;
	
}
