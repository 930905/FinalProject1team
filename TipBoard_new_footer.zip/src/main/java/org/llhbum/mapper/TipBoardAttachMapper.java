package org.llhbum.mapper;

import java.util.List;

import org.llhbum.domain.TipBoardAttachVO;

public interface TipBoardAttachMapper {

	public void insert(TipBoardAttachVO vo);
	
	public void delete(String uuid);
	
	public List<TipBoardAttachVO> findByBno(Long bno);
	
	public void deleteAll(Long bno);
	
	public List<TipBoardAttachVO> getOldFiles();
}
