package org.llhbum.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.llhbum.domain.Criteria;
import org.llhbum.domain.TipReplyPageDTO;
import org.llhbum.domain.TipReplyVO;
import org.springframework.stereotype.Service;

public interface TipReplyService {
	
	public int register(TipReplyVO vo);
	
	public TipReplyVO get(Long rno);
	
	public int remove(Long rno);
	
	public int modify(TipReplyVO vo);
	
	public List<TipReplyVO> getList(Criteria cri, Long bno);
	
	public TipReplyPageDTO getListPage(Criteria cri, Long bno);
		
}
