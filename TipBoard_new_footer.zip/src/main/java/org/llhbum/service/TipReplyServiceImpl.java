package org.llhbum.service;

import java.util.List;

import org.llhbum.domain.Criteria;
import org.llhbum.domain.TipReplyPageDTO;
import org.llhbum.domain.TipReplyVO;
import org.llhbum.mapper.TipBoardMapper;
import org.llhbum.mapper.TipReplyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class TipReplyServiceImpl implements TipReplyService {
	
	@Autowired
	private TipReplyMapper mapper;
	
	@Autowired
	private TipBoardMapper boardMapper;
	
	@Override
	public int register(TipReplyVO vo) {
		log.info("register..................................");
		boardMapper.updateReplyCnt(vo.getBno(), 1);
		return mapper.insert(vo);
	}

	@Override
	public TipReplyVO get(Long rno) {
		log.info("get..................................");
		return mapper.read(rno);
	}

	@Transactional
	@Override
	public int remove(Long rno) {
		log.info("remove..................................");
		
		TipReplyVO vo = mapper.read(rno);
		
		boardMapper.updateReplyCnt(vo.getBno(), -1);
		return mapper.delete(rno);
	}

	@Override
	public int modify(TipReplyVO vo) {
		log.info("modify..................................");
		return mapper.update(vo);
	}

	@Override
	public List<TipReplyVO> getList(Criteria cri, Long bno) {
		log.info("getList..................................");
		return mapper.getListwithPaging(cri, bno);
	}

	@Override
	public TipReplyPageDTO getListPage(Criteria cri, Long bno) {
		// TODO Auto-generated method stub
		return new TipReplyPageDTO(
				mapper.getCountByBno(bno),
				mapper.getListwithPaging(cri, bno)
				);
	}
	
	

}
