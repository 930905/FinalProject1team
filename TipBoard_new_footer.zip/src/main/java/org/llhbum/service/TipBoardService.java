package org.llhbum.service;

import java.util.List;

import org.llhbum.domain.TipBoardAttachVO;
import org.llhbum.domain.TipBoardVO;
import org.llhbum.domain.Criteria;
import org.llhbum.mapper.TipBoardMapper;
import org.springframework.stereotype.Service;

// 4. service 구축
// 서비스는 비지니스 용어를 사용해야함
public interface TipBoardService {
	
	void register(TipBoardVO board);
	
	TipBoardVO get(Long bno);
	
	boolean modify(TipBoardVO board);
	
	boolean remove(Long bno);
	
	List<TipBoardVO> getList();
	
	List<TipBoardVO> getList(Criteria cri);
	
	int getTotal(Criteria cri);
	
	public List<TipBoardAttachVO> getAttachList(Long bno);
	
}
