package org.llhbum.mapper;

import java.util.List;
import java.util.stream.IntStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.llhbum.domain.Criteria;
import org.llhbum.domain.TipReplyVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTests {
	
	@Autowired
	private TipReplyMapper mapper;
	
 
	
	@Test
	public void testCreate() {
		
		TipReplyVO vo = new TipReplyVO();
		vo.setBno(3670092L);
		vo.setReply("강두기만세");
		vo.setReplyer("강두기");
		
		mapper.insert(vo);
	}
	
	@Test
	public void testRead() {
		
		TipReplyVO vo = new TipReplyVO();
		vo = mapper.read(1L);
		log.info(vo);
	}
	
	@Test
	public void testDelete() {
		int result = mapper.delete(1L);
		log.info(result);
	}
	
	@Test
	public void testUpdate() {
		TipReplyVO vo = new TipReplyVO();
		vo.setReply("강두기 저질");
		vo.setRno(3L);
		int cnt = mapper.update(vo);
		
		log.info(cnt);
	}
	
	@Test
	public void testList() {
		Criteria cri = new Criteria(1,10);
		List<TipReplyVO> reply = mapper.getListwithPaging(cri, 3670092L);
		reply.forEach(replies -> log.info(reply));
	}
	
	@Test
	public void testList2() {
		Criteria cri = new Criteria(2,10);
		List<TipReplyVO> replies = mapper.getListwithPaging(cri, 3670092L);
		replies.forEach(reply->log.info(reply));
	}
	
	
	@Test
	public void testMapper(){
		log.info(mapper);
	}
}
