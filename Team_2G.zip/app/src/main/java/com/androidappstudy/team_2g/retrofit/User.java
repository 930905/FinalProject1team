package com.androidappstudy.team_2g.retrofit;

public class User {

    String userId;
    String userPassword;
//    String userName;
//    String userEmail;
//    String userBirth;
//    String userAddress;
//    String userGender;
//    String userP_num;

//    public String getUserBirth() {
//        return userBirth;
//    }
//
//    public void setUserBirth(String userBirth) {
//        this.userBirth = userBirth;
//    }
//
//    public String getUserAddress() {
//        return userAddress;
//    }
//
//    public void setUserAddress(String userAddress) {
//        this.userAddress = userAddress;
//    }
//
//    public String getUserGender() {
//        return userGender;
//    }
//
//    public void setUserGender(String userGender) {
//        this.userGender = userGender;
//    }
//
//    public String getUserP_num() {
//        return userP_num;
//    }
//
//    public void setUserP_num(String userP_num) {
//        this.userP_num = userP_num;
//    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

//    public String getUserName() {
//        return userName;
//    }
//
//    public void setUserName(String userName) {
//        this.userName = userName;
//    }
//
//    public String getUserEmail() {
//        return userEmail;
//    }
//
//    public void setUserEmail(String userEmail) {
//        this.userEmail = userEmail;
//    }
}
