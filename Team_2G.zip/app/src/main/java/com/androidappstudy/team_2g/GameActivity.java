package com.androidappstudy.team_2g;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;

public class GameActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.active_gamemain);

        // ActionBar 설정
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setIcon(R.drawable.ic_launcher_foreground);
            setTitle("게임 소개");
        }

        final GridView gv = (GridView) findViewById(R.id.gridview1);
        MyGridAdapter gAdapter = new MyGridAdapter(this);
        gv.setAdapter(gAdapter);


        Button btnCompany = (Button)findViewById(R.id.btn_company);
        btnCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), About.class);
                startActivity(intent);
            }
        });

        Button btnGame = (Button)findViewById(R.id.btn_game);
        btnCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), About.class);
                startActivity(intent);
            }
        });

        Button btnLocation = (Button)findViewById(R.id.btn_location);
        btnLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LocationActivity.class);
                startActivity(intent);
            }
        });

        Button btnLogout = (Button)findViewById(R.id.btn_logout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });

        TextView nav_bar = (TextView) findViewById(R.id.nav_bar);
        nav_bar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }

    public class MyGridAdapter extends BaseAdapter{


        Context context;

        public MyGridAdapter(Context context) {
            this.context = context;
        }

        Integer[] posteID = {R.drawable.game1, R.drawable.game2, R.drawable.game3, R.drawable.game4, R.drawable.game5, R.drawable.game6, R.drawable.game7, R.drawable.game8, R.drawable.game9, R.drawable.game10,
                R.drawable.game11 ,R.drawable.game12};

        // 다이얼로그 팝업창의 Title 내용에 들어갈 posterTitle 배열 내용을 정의함
        String[] posterTitle = { "버블버블", "백발백중 퉁키", "라이언 서커스", "뿌셔뿌셔","냠냠쩝쩝",
                "에어플레인 모드", "바나나 그리고 사과", "에어플레인 모드2", "지옥불 피하기", "내 집마련 프로젝트",
                "쿵푸 마스터", "분노의 한일전"};

        String[] posterText = { "\"원 투 쓰리 포~♬ 버블버블~♪\"", "\"대장부는,도전해오는 적에게 등을 보여선 안되는거야!\"","\"하쿠나 마타타!!\"", "\"줄 데미지 0콤보 - 에잇,\"", "\"와구 와구! waka waka!\"", "\"내 이름은 P-38. 슈퍼 에이스죠.\"",
                "\"원숭이 엉덩이는 빨개~\"", "\"2G폰 에어플레인 모드\"", "\" 조심하세요. 쿠마 불꽃보다 더 뜨겁습니다.\"", "\"내 집마련 프로젝트\"","\"참고로 개발자는 태권도 3단 검도 3단 축구 20년차 입니다.\"", "\"다른건 몰라도 일본은 무조건 이겨야 한다.\""};

        String[] posterText1 = {"게임은 시작부터 목표를 가진 레벨로 시작합니다. 목표는 특정 수의 매치 또는 버블을 모두 제거하는 것일 수 있습니다플레이어는 하단의 발사대에서 버블을 조준하고 발사합니다. 버블을 발사하여 일련의 매치를 만들거나 동일한 색상의 버블을 연결하여 제거합니다. 각 레벨에 따라 제한된 시간 또는 제한된 발사수가 있을 수 있습니다. 게임의 목표를 달성하면 다음 레벨로 진행하거나 보너스를 획득합니다.",
                "플레이어 캐릭터는 좌우로 움직이며, 화면 하단에서 발사하는 무기로 적 캐릭터나 장애물을 제거하려고 노력합니다. 플레이어는 적의 공격을 피하고, 무기를 발사하여 적을 격파하거나 피하는 데 주력합니다. 게임 중에 파워업 아이템을 얻고, 파워업을 활용하여 더 강력한 무기로 적을 제거합니다.",
                "게임에서 사자는 불꽃을 가로지르며 이동하고, 동그라미 모양의 화면을 뛰어넘어가는 점프를 수행합니다. 게임 중에 다양한 장애물과 적 캐릭터들이 나타나며, 플레이어는 이들을 피해야 합니다. 게임은 여러 레벨로 구성되며, 각 레벨은 더 복잡한 장애물과 도전을 제공합니다. 게임은 플레이 시간이 제한되어 있어, 플레이어는 주어진 시간 내에 레벨을 클리어해야 합니다.",
                "게임의 핵심 요소인 블록 조각은 다양한 모양과 크기를 가집니다. 각 블록 조각은 작은 정사각형 블록으로 구성되며, 이 블록들이 다양한 조합으로 구성된 블록 조각이 위쪽에서 아래쪽으로 떨어집니다. 플레이어는 블록 조각을 좌우로 이동시키거나 회전시킬 수 있습니다. 가로줄이 블록 조각으로 꽉 차면 해당 줄은 삭제되며, 위에 있는 블록들은 아래로 내려와 빈 공간을 메꾸게 됩니다. 이로 인해 추가적인 점수를 얻을 수 있습니다.",
                "게임 필드에는 작은 점 또는 먹이들이 랜덤하게 분포되어 있습니다. 팩맨은 이 먹이들을 먹어가며 점수를 획득합니다. 게임 필드에는 고스트라고 불리는 적 캐릭터가 있습니다. 이 고스트들은 팩맨을 추격하려고 하며, 팩맨이 고스트에 닿으면 생명을 하나 잃게 됩니다. 게임 필드에는 팩맨이 먹을 수 있는 큰 점 또는 슈퍼 점이 있습니다.",
                "플레이어는 게임 시작 시 다양한 비행기 중 하나를 선택할 수 있으며, 각 비행기는 공격 패턴, 속도 및 무기 유형 등에서 차이가 있습니다. 비행기는 주무기와 부수무기를 사용할 수 있습니다. 주무기는 연속 사격으로 적을 공격하며, 부수무기는 강력한 공격을 실행하는 대신 제한된 사용 횟수가 있습니다. 게임 중에 아이템 상자가 나타나며, 이를 파괴하면 다양한 파워업 아이템을 얻을 수 있습니다.",
                "게임은 4개의 레벨로 구성되어 있으며, Donkey Kong(도너키 콩크)가 떨어뜨리는 버럴이나 다른 물체가 포함되어 있습니다. 이러한 장애물을 피해야 합니다. 감옥 위에서 엄마 원숭이가 기다리고 있습니다. Donkey Kong이 던지는 장애물을 피하고 오르막을 올라가서 감옥에 갇힌 엄마 원숭이를 구하는 것입니다. 이 과정에서 다양한 장애물을 피하고, 사다리를 이용하여 다음 레벨로 이동해야 합니다.",
                "플레이어는 게임 시작 시 다양한 비행기 중 하나를 선택할 수 있으며, 각 비행기는 공격 패턴, 속도 및 무기 유형 등에서 차이가 있습니다. 비행기는 주무기와 부수무기를 사용할 수 있습니다. 주무기는 연속 사격으로 적을 공격하며, 부수무기는 강력한 공격을 실행하는 대신 제한된 사용 횟수가 있습니다. 게임 중에 아이템 상자가 나타나며, 이를 파괴하면 다양한 파워업 아이템을 얻을 수 있습니다.",
                "마리오와 루이지는 화면 중간 또는 하단에 위치하며, 위쪽으로 스크롤되는 게임 화면을 따라 이동합니다. 게임 화면 상단에서 불꽃 또는 불덩이가 떨어져 내려오거나 발사됩니다. 플레이어는 이러한 불꽃을 피하려고 점프하거나 이동합니다. 게임 화면은 상향 방향으로 스크롤되므로, 플레이어는 계속해서 올라가야 합니다. 불꽃을 피하면서 스크롤링 화면을 따라가야 합니다. 불꽃을 피하고 공주를 구하세요.",
                "게임은 여러 개의 미로 레벨로 구성되며, 각 레벨은 다양한 형태의 미로와 장애물로 가득합니다. 생쥐는 미로 내에서 이동합니다. 생쥐의 목표는 미로 내에서 흩어진 치즈를 수집하는 것입니다. 플레이어는 생쥐를 조종하여 치즈 아이템을 획득합니다. 미로 내에는 다양한 장애물이 존재합니다. 이러한 장애물을 피하거나 극복해야 합니다. 장애물은 벽, 함정, 고양이 등이 될 수 있습니다.",
                "캐릭터는 주먹과 발차기를 사용할 수 있습니다. 게임에서는 여러 종류의 적들이 나타나며, 각각 다른 공격 패턴과 능력을 가지고 있습니다. 게임은 플랫폼 스타일의 2D 레벨을 따라 진행됩니다. 플레이어는 이동하고 점프하여 적들을 피하거나 공격합니다. \"쿵푸 마스터\"는 여러 스테이지로 구성되어 있으며, 각 스테이지는 다양한 배경과 적들을 제공합니다. 스테이지를 클리어하면 더 어려운 스테이지로 진행합니다.",
                "플레이어는 다양한 축구 팀 중 하나를 선택할 수 있습니다. 각 팀은 현실 세계의 프로 축구 팀을 기반으로 하며, 선수들은 실제 선수들의 능력과 특징을 반영합니다. 게임에는 다양한 경기 모드가 포함되어 있습니다. 예를 들어, 일반 친선 경기, 리그 경기, 카스터마이즈된 토너먼트 및 국가대표팀과 같은 다양한 경기 모드로 게임을 즐길 수 있습니다."};

        @Override
        public int getCount() {
            return posteID.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }
        // 아래 int 타입의 i 파라미터를 position 파라미터로 수정(변경) 코딩 하시기 바랍니다.
        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {
            ImageView imageView;
            if (view == null) {
                imageView = new ImageView(context);
                imageView.setLayoutParams(new ViewGroup.LayoutParams(700, 800)); // 원하는 이미지 크기로 조절
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setPadding(5, 20, 5, 20);
            } else {
                imageView = (ImageView) view;
            }

            // Glide를 사용하여 GIF 이미지를 로드하고 표시
            RequestOptions requestOptions = new RequestOptions()
                    .diskCacheStrategy(DiskCacheStrategy.DATA); // 캐시를 사용하여 GIF 이미지를 로드

            // 프레임별로 크기 조절을 위해 asBitmap() 메서드 사용
            Glide.with(context)
                    .asBitmap() // 각 프레임을 비트맵 이미지로 로드
                    .load(posteID[position]) // GIF 이미지의 리소스 ID 또는 URL
                    .apply(requestOptions) // 위에서 정의한 RequestOptions를 적용
                    .into(new SimpleTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                            // 비트맵 이미지 크기를 조절하고 ImageView에 설정
                            Bitmap resizedBitmap = Bitmap.createScaledBitmap(resource, 700, 800, false);
                            imageView.setImageBitmap(resizedBitmap);
                        }
                    });
//            imageView.setImageResource(posteID[position]);
            final int pos = position;
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    View dialogView = (View) View.inflate(GameActivity.this, R.layout.game_dialog, null);
                    ImageView ivPoster = (ImageView) dialogView.findViewById(R.id.ivPoster);
                    AlertDialog.Builder dig = new AlertDialog.Builder(GameActivity.this);


                    // Glide를 사용하여 GIF 이미지를 로드하고 표시
                    RequestOptions dialogRequestOptions = new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.DATA); // 캐시를 사용하여 GIF 이미지를 로드
                    Glide.with(GameActivity.this)
                            .asGif() // GIF 이미지로 로드
                            .load(posteID[pos]) // GIF 이미지의 리소스 ID 또는 URL
                            .apply(dialogRequestOptions) // 위에서 정의한 RequestOptions를 적용
                            .into(ivPoster);

                    // 다이얼로그 팝업창의 Title 내용에 posterTitle 배열 내용 적용함
                    dig.setIcon(R.drawable.gamelogo);
                    dig.setView(dialogView);
//                    dig.setTitle("게임 제목 : " + posterTitle[pos] + "\n" + posterText[pos]);
                    dig.setTitle("게임 제목 : " + posterTitle[pos]);
                    dig.setMessage(posterText[pos] + "\n" + "\n" +posterText1[pos]);
                    dig.setNegativeButton("닫기", null);
                    dig.show();
                }
            });
            return imageView;
        }
    }
}