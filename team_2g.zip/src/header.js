import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Button from 'react-bootstrap/Button';
import React, { useEffect, useState } from 'react';
import "./css/common.css";
// react-bootstrap/Navbar
// https://react-bootstrap.netlify.app/docs/components/navbar/

function ReactBootstrapNavbars() {
  const [isLogin, setIsLogin] = useState(false);
  const name = sessionStorage.name;

  // 로그인 상태 관리
  useEffect(() => {
    if (sessionStorage.getItem('member_id') === null) {
      console.log('isLogin 상태 = ', isLogin)
    } else {
      // 로그인 상태 변경
      setIsLogin(true)
      console.log('isLogin 상태 = ', isLogin)
    }
  });

  const onLogout = () => {
    alert("로그아웃 되셨습니다!");
    // sessionStorage에 저장되어 있는 아이템을 삭제 처리 합니다.
    sessionStorage.removeItem('member_id');
    sessionStorage.removeItem('name');
    // '/' url로 이동 처리함(새로고침)
    document.location.href = '/';
  }

  return (
    <Navbar bg="white" expand="lg" className='navbar'>
      <Container>
        <Navbar.Brand href="/" className='logo'><img src='./img/logo.png' alt='로고이미지' /></Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mx-auto font align-items-center">
            <Nav.Link className='nav_margin' href="/About"><p>회원관리</p></Nav.Link>
            <Nav.Link className='nav_margin' href="/order"><p>주문현황</p></Nav.Link>
            <Nav.Link className='nav_margin' href="/About"><p>공지사항</p></Nav.Link>
            <Nav.Link className='nav_margin' href="/About"><p>자유게시판</p></Nav.Link>
          </Nav>
          {isLogin
            ?
            <>
              <div className='login_form'>
                <label className='welcome'>{name}님 환영합니다!</label>
                <Button className='logout_btn' variant="outline-secondary" onClick={onLogout}>로그아웃</Button>
              </div>
            </>
            :
            <Button className='login_btn' variant="outline-secondary" href='/Login'>로그인</Button>
          }



        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default ReactBootstrapNavbars;