import React from 'react';
import Header from './header'
import Footer from './Footer'
const Home = () => {
    return (
        <div>
            <Header />
            하위 ㅎㅎ
            <Footer />
        </div>
    );
};

export default Home;