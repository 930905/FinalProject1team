import React, { Component } from 'react';
import { Route, Switch } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.css';
import Order from './order';
import Home from './Home';
import Event from './Event'
class App extends Component {
    render() {
      return (
        <div>
          <Switch>
            <Route exact path="/" component={Home} />
            <Route exact path="/order" component={Order} />
            <Route exact path="/event" component={Event} />
          </Switch>
          
        </div>
      );
    }
  }
export default App;