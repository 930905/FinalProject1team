import './css/event.css'
import Container from 'react-bootstrap/Container';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
const Event = () => {

    const [data, setData] = useState([]);
    const [rank, setRank] = useState([]);
    const [formData, setFormData] = useState({
        eno: ''
    });

    const handleValueChange = (e) => {
        setFormData(e.target.value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const isConfirmed = window.confirm('투표를 제출하시겠습니까?');

        // 여기에서 폼 데이터를 사용하여 원하는 동작 수행
        if (isConfirmed) {
            console.log('Selected Option:', formData);
            try {
                const rank_insert = await axios.post(`http://localhost:9008/vote/${formData}`);
                console.log(rank_insert);
                const rank = await axios.get('http://localhost:9008/rank');
                setRank(rank.data);
                const data = await axios.get('http://localhost:9008/event/Console');
                setData(data.data);
            } catch (error) {
                console.error('투표 실패 : ', error.message);
            }
        }
        // 서버로 데이터를 전송하거나 다른 로직을 수행할 수 있습니다.
    };

    useEffect(() => {
        const fetchData = async () => {

            try {
                const data = await axios.get('http://localhost:9008/event/Console');
                setData(data.data);
                console.log(data.data);

                const rank = await axios.get('http://localhost:9008/rank');
                setRank(rank.data);
                console.log(rank.data);

            } catch (error) {
                console.error('데이터 가져오기 실패:', error);
            }
        };

        fetchData();
    }, []); // 빈 배열을 전달하여 컴포넌트가 마운트될 때 한 번만 호출되게 함
    return (
        <div style={{ backgroundColor: '#320000' }}>
            <Container>
                <div className='background'>
                    <h1 className='title'>고전게임 올스타즈</h1>
                    <div className='event_sub'>
                        <Form onSubmit={handleSubmit}>
                            <Form.Group className='col-md-12'>
                                {data.list && data.list.map((item, index) => (
                                    <div key={item.pno} className={`c_${item.pno} size col-md-3`}>
                                        <div className='vote'>
                                            <Form.Check
                                                style={{ display: 'inline-block', marginRight: '10px' }}
                                                type={'radio'}
                                                name="vote"
                                                value={(index + 1).toString()}
                                                onChange={handleValueChange}
                                            />
                                            <Form.Label className="ml-2">{item.pname}</Form.Label>
                                        </div>
                                    </div>
                                ))}
                            </Form.Group>
                            <Button variant='primary' type='submit' className='vote_btn'>
                                투표하기
                            </Button>
                        </Form>
                    </div>
                    <div className='rank'>
                        {rank.list && rank.list.map((item, index) => (
                            <div key={item.pno}>
                                <span className={`rank${index + 1}`}>{index + 1}위 : {item.pname}</span>
                                {/* <span>투표수 : {item.vote}</span> */}
                            </div>
                        ))}
                    </div>
                </div>
            </Container>
        </div>
    );
};

export default Event;