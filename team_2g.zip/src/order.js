import './css/order.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Container from 'react-bootstrap/Container';
import Button from "react-bootstrap/Button";
import Table from 'react-bootstrap/Table';
import Card from 'react-bootstrap/Card';
import Header from "./header";
import Footer from './Footer';
function Order() {
  const [data, setData] = useState([]);


  const orderAccept = async (pnoToAccept) => {
    const confirmAccept = window.confirm('주문을 접수하시겠습니까?');

    if (confirmAccept) {
      try {
        // 클라이언트에서 서버로 UPDATE 요청을 보냅니다.
        const response = await axios.put(`http://localhost:9008/order_update/${pnoToAccept}`, data);
        alert(`${pnoToAccept}` + "번 상품주문이 접수되었습니다!");
        console.log(response.data);
        // 서버에서 업데이트된 데이터를 받아옵니다.
        const updatedData = await axios.get('http://localhost:9008/order/admin');
        setData(updatedData.data);
        console.log(updatedData.data);
      } catch (error) {
        console.error('주문 접수 실패:', error);
      }
    }
  };

  const orderRemove = async (pnoToRemove) => {
    const confirmDelete = window.confirm('주문을 취소하시겠습니까?');

    if (confirmDelete) {
      try {
        // 클라이언트에서 서버로 DELETE 요청을 보냅니다.
        const response = await axios.delete(`http://localhost:9008/order_delete/${pnoToRemove}`);
        console.log(response.data); // 삭제된 데이터 확인
        alert("취소가 완료되었습니다!");
        // 서버에서 업데이트된 데이터를 받아옵니다.
        const updatedData = await axios.get('http://localhost:9008/order/admin');
        setData(updatedData.data);
        console.log(updatedData.data);
      } catch (error) {
        console.error('주문 삭제 실패:', error);
      }
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:9008/order/admin');
        setData(response.data);
        console.log(response.data);
      } catch (error) {
        console.error('데이터 가져오기 실패:', error);
      }
    };

    fetchData();
  }, []); // 빈 배열을 전달하여 컴포넌트가 마운트될 때 한 번만 호출되게 함
  return (
    <div>
      <Header />
      <Container style={{ margin: '40px auto 70px auto' }}>
        <Card style={{ marginBottom: '40px' }}>
          <Card.Body>
            <Card.Title>
              <h1 style={{ marginTop: '0.5rem' }}>주문현황</h1>
            </Card.Title>
          </Card.Body>
        </Card>
        <Table striped bordered hover>
          <thead>
            <tr className='header'>
              <th className='col-md-1'>주문번호</th>
              <th className='col-md-1'>상품번호</th>
              <th className='col-md-3'>상품명</th>
              <th className='col-md-1'>주문수량</th>
              <th className='col-md-1'>주문가격</th>
              <th className='col-md-1'>주문자</th>
              <th className='col-md-1'>주문일자</th>
              <th className='col-md-1'>주문상태</th>
              <th className='col-md-2'>처리</th>
            </tr>
          </thead>
          {data.list && data.list.map(item => (
            <tr key={item.pno} className='table_sub'>
              <td>{item.pno}</td>
              <td>{item.pnum}</td>
              <td>{item.pname}</td>
              <td>{item.pamount}</td>
              <td>{item.p_price}</td>
              <td>{item.pbuyer}</td>
              <td>{item.pdate}</td>
              <td>{item.order_status}</td>
              <td style={{ padding: '10px' }}>
                <Button className='buy_btn' variant="primary" onClick={() => orderAccept(item.pno)}>주문완료</Button>
                <Button className='can_btn' variant="danger" onClick={() => orderRemove(item.pno)}>주문취소</Button>
              </td>
            </tr>
          ))}
        </Table>
      </Container>
      <Footer />
    </div>
  );
}

export default Order;
