package org.zerock.service;

public interface SampleTxService {

	public void addData(String value);
}
