import React, { Component } from 'react';
import MemberService from './MemberService';
import { Container } from 'react-bootstrap';
import axios from 'axios';

class MemberList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      boards: [],
    };
  }

  componentDidMount() {
    MemberService.getBoards().then((res) => {
      this.setState({ boards: res.data });
    });
  }

  delete(memberId) {
    console.log("Member ID:", memberId);
    axios
    .post('deleteProcess.do', null, { params: { memberId: memberId } })
    .then((res) => {
      alert('요청이 처리되었습니다!');
      // 회원 삭제 후 다시 회원 목록을 가져와서 클라이언트의 상태를 업데이트합니다.
      MemberService.getBoards().then((res) => {
        this.setState({ boards: res.data });
      });
    })
    .catch((err) => alert('error: ' + err.response.data.msg));
  }
  

  render() {
    return (
      <div>
        <Container>
          <h2 className='text-center'>회원 목록조회</h2>
          <div className='row'>
            <table className='table_list'>
              <thead>
                <tr>
                  <th>아이디</th>
                  <th>비밀번호</th>
                  <th>이름</th>
                  <th>이메일</th>
                  <th>생년월일</th>
                  <th>주소</th>
                  <th>성별</th>
                  <th>전화번호</th>
                  <th>선택</th>
                </tr>
              </thead>
              <tbody>
                {this.state.boards.map(board => (
                  <tr key={board.memberId}>
                    <td>{board.memberId}</td>
                    <td>{board.memberPassword}</td>
                    <td>{board.memberName}</td>
                    <td>{board.memberEmail}</td>
                    <td>{board.memberBirth.substring(0, 10)}</td>
                    <td>{board.memberAddress}</td>
                    <td>{board.memberGender}</td>
                    <td>{board.memberP_num}</td>
                    <td>
                      <button onClick={() => this.delete(board.memberId)}>회원 삭제</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Container>
      </div>
    );
  }
}

export default MemberList;