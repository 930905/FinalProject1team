package org.llhbum.mapper;

import org.llhbum.domain.MemberVO;

public interface MemberMapper {
	public MemberVO read(String userid);
}
