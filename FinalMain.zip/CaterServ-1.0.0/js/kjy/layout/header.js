let menuChk = 0;

gsap.to('.ilu svg path',{
    scale : 0.1,
    repeat : -1,
    transformOrigin : "0% 60%",
    yoyo : true,
    ease : "power1.inOut"
})

gsap.to('.ilu',{
    x : -50,
    y : 25,
    duration : 3,
    repeat : -1,
    yoyo : true,
    ease : "power1.inOut"
})

const menu_tl = gsap.timeline({
    defaults: {
        ease : "back.inOut(1.7)",
        duration : 0.4
    },
})
.to('header .gnb .menu span:nth-of-type(1)',{
    width : "100%"
},'a')
.to('header .gnb .menu span:nth-of-type(3)',{
    width : "100%"
},'a')
.to('header .gnb .menu span:nth-of-type(2)',{
    left : "-100%",
    opacity : 0
})
.to('header .gnb .menu span:nth-of-type(1)',{
    rotate : 45,
    top : "50%"
},'b')
.to('header .gnb .menu span:nth-of-type(3)',{
    rotate : -45,
    top : "50%"
},'b');
menu_tl.pause();

const site_tl = gsap.timeline({
})
.to('.stbx .b',{
    x : "0%",
    duration : 0.4
})
.to('.stbx .w',{
    x : "0%",
    duration : 0.4
},">-=50%")
.to('.stbx .sitemap',{
    x : "0%",
    duration : 0.7
},">-=50%");
site_tl.pause();

$('header .gnb .menu').click(function(){
    if(menuChk == 0) {
        site_tl.play();
        menu_tl.play();
        menuChk = 1;
    } else {
        site_tl.reverse();
        menu_tl.reverse();
        menuChk = 0;
    }
});


$('.stbx .sitemap .s_gnb>li dl dt').each((i,el)=>{
    const text = $(el).text().trim().split('');
    
    $(el).empty();

    // $(el).append('<div class="bar"></div>')

    for(let i = 0; i < text.length; i++){
        const span = document.createElement('span');
        span.innerText = text[i];
        if(i % 2 == 1) span.style.zIndex = 3;
        if(i % 2 == 1) span.style.position = 'relative';
        el.append(span);
    }

});
