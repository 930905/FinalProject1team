(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner(0);
    
    
    // Initiate the wowjs
    new WOW().init();
    
    
   // Back to top button
   $(window).scroll(function () {
    if ($(this).scrollTop() > 300) {
        $('.back-to-top').fadeIn('slow');
    } else {
        $('.back-to-top').fadeOut('slow');
    }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Modal Video
    $(document).ready(function () {
        var $videoSrc;
        $('.btn-play').click(function () {
            $videoSrc = $(this).data("src");
        });
        console.log($videoSrc);

        $('#videoModal').on('shown.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        })

        $('#videoModal').on('hide.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc);
        })
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // gamemain1 carousel
    $(".gamemain1_carousel_1").owlCarousel({
        loop: true,
        dots: true,
        margin: 25,
        autoplay: true,
        dots: true,
        slideTransition: 'linear',
        autoplayTimeout: 3000,
        autoplaySpeed: 1000,
        autoplayHoverPause: false,
        // responsive: {
        //     0:{
        //         items:1
        //     },
        //     575:{
        //         items:1
        //     },
        //     767:{
        //         items:2
        //     },
        //     991:{
        //         items:3
        //     }
        // }
    });

   var $carousel = $(".gamemain1_carousel_1");
    var $customDot = $(".custom-dot");

    $carousel.owlCarousel({
        // 기존 Owl Carousel 설정
        // ...
    });

    $customDot.on("click", function () {
        var index = $(this).data("index");
        $carousel.trigger("to.owl.carousel", index);
    });

    $carousel.on("changed.owl.carousel", function (event) {
        var currentSlide = event.item.index;
        
        // 모든 custom-dot에서 활성 클래스 제거
        $customDot.removeClass("active");
        
        // 현재 슬라이드에 해당하는 custom-dot에 활성 클래스 추가
        $customDot.eq(currentSlide).addClass("active");
    });

    // 닷 초기 설정
    var dot1 = $(".owl-dot:nth-child(1)");
    var dot2 = $(".owl-dot:nth-child(2)");
    var dot3 = $(".owl-dot:nth-child(3)");
    var dot4 = $(".owl-dot:nth-child(4)");

    var originalColor = "black"; 

    // 초기 설정
    dot1.css("background", originalColor);
    dot2.css("background", originalColor);
    dot3.css("background", originalColor);
    dot4.css("background", originalColor);

    var animationDuration = 3000;

    $(".gamemain1_carousel_1").on("changed.owl.carousel", function(event) {
        var currentSlide = event.page.index;

        // 해당 슬라이드의 닷에만 활성 클래스 추가
        $(".owl-dot").removeClass("active");
        $(".owl-dot:nth-child(" + (currentSlide + 1) + ")").addClass("active");

        // 해당 슬라이드의 닷에 애니메이션 적용
        $(".owl-dot.active").stop().animate({ width: "200px", background: originalColor}, animationDuration);

        // 나머지 닷 초기 크기와 배경색 유지
        $(".owl-dot:not(.active)").stop().css({ width: "15%", background: "red" });
    });

    // Testimonial carousel
    $(".testimonial-carousel-1").owlCarousel({
        loop: true,
        dots: false,
        margin: 25,
        autoplay: true,
        slideTransition: 'linear',
        autoplayTimeout: 0,
        autoplaySpeed: 10000,
        autoplayHoverPause: true,
        responsive: {
            0:{
                items:1
            },
            575:{
                items:1
            },
            767:{
                items:2
            },
            991:{
                items:3
            }
        }
    });

    $(".testimonial-carousel-2").owlCarousel({
        loop: true,
        dots: false,
        rtl: true,
        margin: 25,
        autoplay: true,
        slideTransition: 'linear',
        autoplayTimeout: 0,
        autoplaySpeed: 10000,
        autoplayHoverPause: true,
        responsive: {
            0:{
                items:1
            },
            575:{
                items:1
            },
            767:{
                items:2
            },
            991:{
                items:3
            }
        }
    });

})(jQuery);

