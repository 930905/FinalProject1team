import React, { useEffect } from "react";
import AOS from "aos";
import Container from 'react-bootstrap/Container';
import "../css/aos.css";
import ReactBootstrapNavbars from './ReactBootstrapNavbars';
import Footer from './Footer';

const About = () => {
  useEffect(()=>{
    AOS.init({duration: 2000});
  })

  


  return ( 
    <>
    <ReactBootstrapNavbars />
    <Container>
    <>
    <div className="board1">
      <h1>
    <p data-aos="fade-right" className="fade_right">
      회사소개
    </p>   
    </h1>
      <p data-aos="fade-left" className="sub_1">최고의 인테리어 솔루션</p>
      <p data-aos="fade-left" className="sub_2">
        Moenia는 편안한 분위기의 집을 조성한 고객들을 위해 <br/> 
        다양한 스타일과 디자인을 통해 맞춤형 솔루션을 제공하며, <br/>
        집안의 아늑함과 편안함을 향상할 수 있는 최고의 인테리어<br/> 솔루션을 제공하는 전문 업체입니다.
    </p> 
    </div>

    <Container className="F1">
    <img data-aos="fade-up"></img>
        <p className="Fh1" data-aos="fade-down">고객지향</p><br/>
        <p className="Fh2" data-aos="fade-down">
          Moenia의 최우선 가치는 ‘고객’입니다. <br/>내 집만큼은 안락한 공간으로 만들고 싶은
          고객의 <br/>마음에 공감하고,  작은 불편함이라도 귀 기울여 듣습니다.<br/>
          고객의 만족은 우리의 진심에서 오는 것을 믿기에<br/> 만족을 넘어 감동을 위한
          Moenia의 노력은 멈추지 않습니다.</p>
    </Container>

    <Container className="F2">
    <img data-aos="fade-up"></img>
        <p className="Fh3" data-aos="fade-down">지속성장</p><br/>
        <p className="Fh4" data-aos="fade-down">
        변화와 도전은 신한벽지의 성장 발판입니다.<br/>
        작은 차이가 모여 큰 변화를 만들기에 사소한 아이디어도<br/> 놓치지 않고
        끊임없이 도전합니다. 주기적인 시장조사를 통하여 <br/>변화하는 트렌드를 살피고,
        고객의 니즈에 부응하는<br/> 차별화된 디자인과 품질을 연구합니다. </p>
    </Container>

    <Container className="F3">
    <img data-aos="fade-up"></img>
        <p className="Fh5" data-aos="fade-down">상생추구</p><br/>
        <p className="Fh6" data-aos="fade-down">        
        Moenia의 성장은 고객과 임직원 모두의 관심과 노력이 만들어낸 결과입니다.<br/>
        고객, 임직원, 신한벽지 모두가 함께 성장해나갈 수 있도록<br/>
        소통과 협력을 통해 더 큰 미래를 그려나가겠습니다.</p>
    </Container>
    <Container className="F4">

    </Container>
    </>
    </Container>
    <Footer />    
    </>
  );
};

export default About;