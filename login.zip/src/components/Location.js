import '../css/location.css';
import Bus from "../location_images_src/location_bus_icon.svg";
import Subway from "../location_images_src/location_subway_icon.svg";
import Nav from "../location_images_src/location_navigation_icon.svg";
import Park from "../location_images_src/location_parking_icon.svg";
import ReactBootstrapNavbars from './ReactBootstrapNavbars';
import Footer from './Footer';
//  맨위에 global kakao를 선언해서, kakao를 글로벌로 선언해서 사용합니다.
/* global kakao */
import React, {useEffect} from "react";
import Container from "react-bootstrap/Container";

const location_name = "찾아오시는길";

export default function Map(){
    useEffect(()=>{
        kakaoMapScript();
    }, []);

        const kakaoMapScript = () => {
        let container = document.getElementById("map");
        let options = {
            center: new kakao.maps.LatLng(37.5030698, 126.8789856),
            level: 5,
        };
       

                var mapContainer = document.getElementById('map'), // 지도를 표시할 div 
                mapOption = { 
                    center: new kakao.maps.LatLng(37.5030698, 126.8789856), // 지도의 중심좌표
                    level: 3 // 지도의 확대 레벨
                };

            var map = new kakao.maps.Map(mapContainer, mapOption);

            // 마커가 표시될 위치입니다 
            var markerPosition  = new kakao.maps.LatLng(37.5030698, 126.8789856); 

            // 마커를 생성합니다
            var marker = new kakao.maps.Marker({
                position: markerPosition
            });

            // 마커가 지도 위에 표시되도록 설정합니다
            marker.setMap(map);
            

            var iwContent = '<div style="padding:5px;">Moenia <br><a href="https://map.kakao.com/link/map/Hello World!,37.5030698, 126.8789856" style="color:blue" target="_blank">큰지도보기</a> <a href="https://map.kakao.com/link/to/Hello World!,37.5030698, 126.8789856" style="color:blue" target="_blank">길찾기</a></div>', // 인포윈도우에 표출될 내용으로 HTML 문자열이나 document element가 가능합니다
                iwPosition = new kakao.maps.LatLng(33.450701, 126.570667); //인포윈도우 표시 위치입니다

            // 인포윈도우를 생성합니다
            var infowindow = new kakao.maps.InfoWindow({
                position : iwPosition, 
                content : iwContent 
            });
            
            // 마커 위에 인포윈도우를 표시합니다. 두번째 파라미터인 marker를 넣어주지 않으면 지도 위에 표시됩니다
            infowindow.open(map, marker); 

            //마커 리사이즈시 마커위치 고정
            window.addEventListener('resize', function()
            {
                var markerPosition = marker.getPosition(); 
                map.relayout();
                map.setCenter(markerPosition);
            })
     
        };
    

    return(
        <>
        <ReactBootstrapNavbars />
            <Container>
                <div className="location_common">
                    <h1 className='loca'>{location_name} </h1>
                    {/* 카카오맵 정보가 들어올 id 속성값으로 map을 div 영역에 정의해 줍니다 */}
                    <div id="map"></div>
                    <hr />
                    <div className="location_information">
                        <h2>LOCATION INFORMATION</h2>
                        <h3><small>주소 : (123456)서울특별시 구로구 경인로 557 삼영빌딩 4층</small></h3>
                        <h3><small>고객안내센터 : 02-1234-5678</small></h3>
                    </div>
                    <hr />
                    <div className='location_information_add'>
                        {/* 교통(traffic) 정보 추가 */}
                        <div className='location_traffic'>
                          <div className='traffic_details'>
                            <img src={Bus} alt="버스 아이콘" />
                            <h2 className='trans'>버스</h2>                            
                          </div>
                        <h2 className='details'><small>구로역 일반 지선(녹색) 버스 : 1-1, 9, 9-3, 11-1, 11-2, 11-3, 11-5, 103, 777, 917</small></h2>            
                        </div>
                        <div className='location_traffic'>
                            <div className='traffic_details'>
                            <img src={Subway} alt="지하철 아이콘"/>
                            <h2 className='trans'>지하철</h2>
                            </div>            
                            <h2 className='details'><small>1호선 구로역 하차<br></br>7번 또는 8번 출구로 나와서 150m 직진 지점</small></h2>
                        </div>
                        <div className='location_traffic'>
                            <div className='traffic_details'>
                            <img src={Nav} alt="네비게이션 아이콘"/>
                            <h2 className='trans'>네비게이션<br /> 정보</h2>
                            </div>
                            <h2 className='details'><small>아이나비 네비, 구글 네비 등 네비게이션 "Moenia" 검색</small></h2>
                        </div>
                        <div className='location_traffic'>
                            <div className='traffic_details'>
                            <img src={Park} alt="주차 아이콘"/>
                            <h2 className='trans'>주차안내</h2>
                            </div>
                            <h2 className='details park'><small>Moenia 고객안내센터 1층 주차장 이용</small></h2>
                        </div>
                    </div>
                </div>                     
                </Container>    
               
        <Footer />                 
        </>        
    );
}




