import React from "react";
import Container from 'react-bootstrap/Container';
import Accordion from 'react-bootstrap/Accordion';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import 'bootstrap/dist/css/bootstrap.css'; 
import '../css/qna.css';
import ReactBootstrapNavbars from './ReactBootstrapNavbars';
import Footer from './Footer';


// https://react-bootstrap.netlify.app/docs/components/accordion/

function QnA() {
  return (
    <>
    <ReactBootstrapNavbars />
    <div className="bgimg">
    <Container>
    <div className="boxx">
    <Tabs 
    
      defaultActiveKey="카테고리"
      id="uncontrolled-tab-example"
      className="mb-3"
    >
      
      <Tab eventKey="카테고리" title="카테고리">
      
    <Accordion defaultActiveKey=" ">
      <Accordion.Item eventKey="0">

        <Accordion.Header><i class="fa-solid fa-comments"></i>  카테고리별 이미지 샘플은 어떻게 신청하나요?</Accordion.Header>
        
        <Accordion.Body>
        Moenia는 고객님의 맞춤 시공을 위해 집에서 편하게 벽지를 선택할 수 있도록
        벽지 원단 샘플 서비스를 제공해드리고 있습니다.
        <br></br>     
        샘플은 A4 사이즈로 제공되며, 발송 후 지역에 따라 3~5일 정도 소요될 예정입니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header><i class="fa-solid fa-comments"></i>우드 필름과 솔리드 필름 차이가 무엇인가요?</Accordion.Header>
        <Accordion.Body>
        - 솔리드 필름은 무늬가 없는 필름입니다. 깔끔한 느낌을 주지만 시공대상의 상태가 좋지 않거나 살면서 손상이 가는 경우 티가 잘 납니다.
        <br></br>
        - 우드 필름은 나뭇결로 무늬가 있는 필름입니다. 시공대상의 상태가 좋지 않거나 생활하시며 손상이 가는 경우에도 어느 정도 커버가 가능해 티가 잘 나지 않습니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header><i class="fa-solid fa-comments"></i>실크벽지와 합지벽지 차이점이 무엇인가요?</Accordion.Header>
        <Accordion.Body>    
        - 합지벽지는 벽지와 벽지 사이를 겹쳐서 시공하기 때문에 이음매가 보입니다.
        <br></br>
        - 실크벽지는 벽지와 벽지 사이를 맞대어 시공하기 때문에 이음매가 거의 보이지 않습니다
        <br></br>
        합지벽지는 종이 벽지이며 실크는 종이 벽지에 코팅이 되어 있습니다.
        기본적으로 벽지 수명이 실크벽지가 더 오래 갑니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="3">
        <Accordion.Header><i class="fa-solid fa-comments"></i>사용하시는 벽지가 친환경 제품인가요?</Accordion.Header>
        <Accordion.Body>
        각 벽지 제조사별로 친환경인증을 받고 나오는 제품만 취급하고 있습니다.
        안심하고 사용하셔도 좋습니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="4">
        <Accordion.Header><i class="fa-solid fa-comments"></i>인테리어 품질을 위한 작업을 따로 하는 부분이 있나요?</Accordion.Header>
        <Accordion.Body>
        필요한 부분에 대해 벽지를 제거하고, 울퉁불퉁한 면을 부직포로 완화하는 시공(초배 작업)을 하고 있습니다.
        <br></br>
        벽지를 제거함으로써 벽지가 들뜨는 현상, 기존 벽지 색상이 배어 나오는 현상을 예방할 수 있습니다.
        <br></br>
        또한, 부직포 시공을 통해 울퉁불퉁한 면을 완화시킬 수 있습니다.
        </Accordion.Body>
      </Accordion.Item>
      </Accordion>
      </Tab>

   
      <Tab className="qnatab" eventKey="결제 및 환불" title="결제 및 환불">
      <Accordion defaultActiveKey="">
      <Accordion.Item eventKey="0">
        <Accordion.Header><i class="fa-solid fa-comments-dollar"></i>계약은 어떻게 진행되나요?</Accordion.Header>
        <Accordion.Body>
          고객님에게 발행된 모바일 견적서의 고객 확인 사항을 꼼꼼히 확인 후 시공을 진행하기 위해 모두 동의해주시면 계약금 입금 정보를 확인할 수 있습니다.
          <br></br>
          계약금이 입금 완료되어야 정상적으로 계약이 완료 됩니다. 순서대로 시공일정이 확정되니 입금이 늦어질 경우 원하시는 일정에 시공이 불가할 수 있습니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header><i class="fa-solid fa-comments-dollar"></i>현금영수증 발행 가능한가요?</Accordion.Header>
        <Accordion.Body>
         Moenia의 모든 견적에는 부가세가 포함되어 있습니다.(2023년 10월 기준)
         <br></br>
         전액 현금영수증 발행이 가능합니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header><i class="fa-solid fa-comments-dollar"></i>결제 영수증은 어디서 확인할 수 있나요?</Accordion.Header>
        <Accordion.Body>
        결제시 입력하신 이메일 주소로 발송된 "현금영수증 발행 안내메일" 에서 확인하실 수 있으며,
        <br></br>
        마이페이지 - 결제 - 결제 내역 확인하기 - 전표 보기 에서도 확인 가능합니다.
        <br></br>
        쇼룸에서 현장 결제 하신 경우 전표 보기 조회 시 카드 번호로만 조회가 가능합니다
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="3">
        <Accordion.Header><i class="fa-solid fa-comments-dollar"></i>시공 취소 관련 환불 안내</Accordion.Header>
        <Accordion.Body>
        시공일로부터 8~15일(시공마다 상이) 이상이 여유가 있는 경우, 시공 취소나 일정 변경은 자유롭게 가능합니다.
        <br></br><br></br>
        다만, 하단에 기재된 기준에 해당할 경우 위약금이 발생합니다.
        <br></br>
        (주말 및 법정 공휴일 제외)
        <br></br>
        - 시공일 14일 전 오후 6시까지 : 계약금 100% 환불
        <br></br>
        - 시공일 14일 전 오후 6시 이후 : 계약금 환불 불가, 
        시공일 14일 전 취소를 원하실 경우 환불은 가능하지만 이미 실측이 진행되었을 경우 실측 비용은 환불 불가합니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="4">
        <Accordion.Header><i class="fa-solid fa-comments-dollar"></i>시공 변경 및 취소 가능 시간</Accordion.Header>
        <Accordion.Body>
        (주말, 법정 공휴일 제외)
        <br></br>
        - 영업일 내 오전 09시 ~ 오후 06시까지 오직 전화 상담을 통한 예약 및 취소/변경 방식만 가능합니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="5">
        <Accordion.Header><i class="fa-solid fa-comments-dollar"></i>시공이 불가할 경우의 환불</Accordion.Header>
        <Accordion.Body>
        1. 고객확인서에 기재된 내용과 현장상황이 상이하여 시공이 불가할 경우, 시공이 취소될 수 있으며, 이 경우 계약금 환불이 불가합니다.
        <br></br>
        2. 기후변화와 천재지변 등의 이유로 시공이 취소될 수 있습니다. 이 경우 일정 변경 혹은 계약금 전액 환불이 가능합니다.
        </Accordion.Body>
      </Accordion.Item>
     </Accordion>
      </Tab>

      <Tab eventKey="인테리어 시공" title="인테리어 시공">
      <Accordion defaultActiveKey="">
      <Accordion.Item eventKey="0">
        <Accordion.Header><i class="fa-solid fa-paint-roller"></i>인테리어 견적은 어떻게 받나요?</Accordion.Header>
        <Accordion.Body>
        인테리어 견적은 시공대상의 굴곡이나 크기, 상태에 따라 시공 견적이 상이합니다.
        그렇기 때문에 필수적으로 사진을 전달받아야 견적이 가능합니다.
        <br></br>
        고객센터로 시공 범위의 사진을 전달해주시면 정확한 견적을 전달 드립니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header><i class="fa-solid fa-paint-roller"></i>거주 중/짐이 있는 경우에도 인테리어가 가능한가요?</Accordion.Header>
        <Accordion.Body>
        거주 중/짐이 있는 경우 인원이 추가되어 도배가 진행됩니다.
        <br></br>
        잔짐(가구 위, 가구 안 등)은 모두 시공범위 제외구역(베란다, 화장실 등)으로 미리 치워주셔야 가구를 옮겨가며 시공 할 수 있습니다.
        <br></br>
        간혹 짐이 많은 경우 시공이 불가한 경우도 있으니 고객센터로 짐 사진을 미리 보내주세요.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header><i class="fa-solid fa-paint-roller"></i>기존에 있던 필름, 벽지는 전부 제거하고 시공하나요?</Accordion.Header>
        <Accordion.Body>
        1. 필름 : 일반적으로 필름 시공은 덧방 시공이 원칙입니다. 하지만 시공 품질을 저하시킬 수 있는 부분을 선택적으로 제거합니다.
        <br></br>
        2. 벽지 : 기존 벽지가 실크인 경우 벽지의 겉지를 모두 제거하고 도배합니다.
                기존 벽지가 합지인 경우 시공 품질을 저하시킬 수 있는 부분을 선택적으로 제거합니다.
                <br></br>
                <br></br>
                벽지를 제거하지 않는 경우는
                <br></br>
                - 벽지를 뜯었을 때 벽체의 노후화로 인해 시멘트가 같이 뜯겨나오는 경우
                <br></br>
                - 기존 벽지가 잘 붙어 있을 때 덧방이 벽면 상태를 완화해 품질이 더 좋은 경우 등이 있습니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="3">
        <Accordion.Header><i class="fa-solid fa-paint-roller"></i>시공 전 반드시 확인해야할 공통적인 사항이 있나요?</Accordion.Header>
        <Accordion.Body>
        - 아래 항목들은 시공 전 반드시 확인해주시면 좋습니다
        <br></br>
        1. Moenia 말고 다른 인테리어 시공이 있다면 Moenia에게 알려주기
        인테리어 시공은 서로 영향을 미치는 경우가 많습니다.
        <br></br>
        2. 시공 예정 지역 쓰레기 봉투와 폐기물 스티커 준비하기 해당 지역의 쓰레기 봉투와 폐기물 스티커는 고객님께서 준비해주셔야 합니다.
        <br></br>
        3. 출입번호 미리 알려주기 시공지에 출입해야 하기 때문에 반드시 알려주셔야 합니다.
        <br></br>
        4. 승강기가 있는 지 확인하기 시공에 사용되는 자재들과 도구들은 무거운 것들이 많습니다. 혼자 옮기기 어려운 경우도 있으니 반드시 승강기 사용 유무를 알려주세요.
        <br></br>
        5. 누수의 흔적, 벽 부서짐이 있다면 미리 알려주기 시공되는 벽체 자체의 손상이 있다면 미리 알려주셔야 시공 마감 퀄리티가 좋습니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="4">
        <Accordion.Header><i class="fa-solid fa-paint-roller"></i>시공 후 청소도 해주시나요?</Accordion.Header>
        <Accordion.Body>
        기본적으로 시공 후 큰 폐자재 뭉치(뜯어낸 기존 벽지, 필름지 등)를 쓰레기봉투에 정리하는 정도입니다.
        <br></br>
        작은 종이 조각, 먼지 등과 도배풀이 묻은 것까지는 청소를 해드리지 않습니다.
        </Accordion.Body>
      </Accordion.Item>
      </Accordion>
      </Tab>

      <Tab eventKey="기타 / 공통" title="기타 / 공통">
      <Accordion defaultActiveKey="">
      <Accordion.Item eventKey="0">
        <Accordion.Header><i class="fa-solid fa-star"></i>주말, 공휴일에도 작업이 가능한가요?</Accordion.Header>
        <Accordion.Body>
         현재 소음이 적게 발생하는 작업 같은 경우는 일요일, 공휴일(명절제외)도 시공은 가능합니다.
         가능 시공 안내 : 벽지, 필름
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header><i class="fa-solid fa-star"></i>인테리어 시공시 주의해야할 점이 따로 있을까요?</Accordion.Header>
        <Accordion.Body>
        1. 귀중품은 전부 치워주세요. 분실의 경우 책임지지 않습니다.
        <br></br>
        2. 가구 위나 가구 등 잔짐을 전부 치워주셔야 가구를 옮기며 시공합니다.<br></br>
        3. 옮기기 힘든 가구의 경우 보이는 부분만 재단되어 시공될 수 있습니다.<br></br>
        4. 가구, 바닥 등 미리 비닐 또는 덮을 것으로 보양을 진행해주세요.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header><i class="fa-solid fa-star"></i>A/S 절차는 어떻게 되나요?</Accordion.Header>
        <Accordion.Body>
        최대한 A/S가 생기지 않도록 시공을 진행하고 있지만 현장 상태에 따라 부득이하게 AS가 생길 수 있어요.
        A/S가 의심된다면 사이트 마이페이지를 통해 접수해주세요. Moenia의 A/S 전담팀이 전화로 고객님에게 전화를 드립니다.
        <br></br>
        - 절차
        <br></br>
        1. 마이페이지 &#10093; A/S 접수해주세요<br></br>
        2. A/S 전담팀이 고객님께 전화드려요<br></br>
        3. 고객님이 편한 시간에 A/S일정을 정합니다<br></br>
        4. 고객님 댁에 반장님이 도착해 A/S를 완료합니다 
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="3">
        <Accordion.Header><i class="fa-solid fa-star"></i>상담부터 시공까지의 절차는 어떻게 되나요?</Accordion.Header>
        <Accordion.Body>
        상담 신청 - 상담 진행 - 실축 받기 - 계약 - 시공 시작 - 잔금결제 - AS 접수  <br></br>
        순으로 절차가 진행 됩니다   
        </Accordion.Body>
      </Accordion.Item>
     </Accordion>
      </Tab>
 
    </Tabs>
    </div>
    </Container>
    </div>
    <Footer />
    </>
  );
}

export default QnA;