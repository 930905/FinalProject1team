import React from "react";
import ReactBootstrapNavbars from "./ReactBootstrapNavbars";
import Footer from "./Footer";

const CommunityBoard = () => {
    return(
        <div>
            <ReactBootstrapNavbars />
            <h1>커뮤니티게시판(CommunityBoard)</h1>
            <p>이 프로젝트는 리액트 라우터 기초를 실행해 보는 예제 프로젝트입니다!</p>
            <Footer />
        </div>
    );
};
export default CommunityBoard;