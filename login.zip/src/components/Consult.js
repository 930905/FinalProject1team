import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Container from 'react-bootstrap/Container';
import ReactBootstrapNavbars from "./ReactBootstrapNavbars";
import Button from "react-bootstrap/Button";
import Footer from "./Footer";
import "../css/Consult.css";
import AOS from "aos";
import '../css/aos.css'


class Consult extends Component {
  componentDidMount() {
    AOS.init({ duration: 2000 });
}
  constructor(props) {
    super(props);
    this.state = {
      moeniaId: sessionStorage.name,
      moeniaTitle: "",
      moeniaContent: ""
    };
    
  }
  crud = () => {
    const { moeniaId, moeniaTitle, moeniaContent } =
      this.state;

    let crudType = "insertProcess.do";

    let form = new FormData();
    form.append("moeniaContent", moeniaContent);
    form.append("moeniaTitle", moeniaTitle);
    form.append("moeniaId", moeniaId);

    axios
      .post(crudType, form)
      .then((res) => {
        alert("상담요청이 완료되었습니다!");
        this.props.history.push("/");
      })
      .catch((err) => alert("error : " + err.response.data.msg));
  }


  render() {

    const moeniaTitle = this.state.moeniaTitle;
    const moeniaContent = this.state.moeniaContent;
    return (
      <>
        <ReactBootstrapNavbars />
        <div className='Qbg' data-aos="fade-up">
        <Container>
         
          <div className='C_qna'>
          <h2 className='ctitle'>1:1 문의하기</h2>
          <h3 className='title2'>제목</h3>
          <input
            placeholder='상담 제목을 입력해 주세요'
            className='ctitle_text'
            type='text'
            value={moeniaTitle || ''}
            onChange={(event) => this.setState({ moeniaTitle: event.target.value })}
          ></input>
          <br />
          <h3 className='qtitle'>문의내용</h3>
          <textarea
            placeholder='상담 내용을 입력해 주세요'
            className='qtitle_text'
            rows="10"
            cols="20"
            value={moeniaContent || ''}
            onChange={(event) => this.setState({ moeniaContent: event.target.value })}
          ></textarea>
          <br /><br />
          <Button className='sbtn' variant="light" onClick={() => this.crud()}>상담하기</Button>
          <Link to="/">
            <Button className='cbtn' variant="light" type='button'>취소</Button>
          </Link>
          </div>
        </Container>
        </div>
        <Footer />
      </>

    );
  }
}

export default Consult;