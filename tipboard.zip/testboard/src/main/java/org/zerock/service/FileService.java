package org.zerock.service;

import org.springframework.web.multipart.MultipartFile;

public interface FileService {

	public static final String IMAGE_REPO="C:/spring/image_repo";
	
	public String saveFile(MultipartFile file);
	
	
	
}

